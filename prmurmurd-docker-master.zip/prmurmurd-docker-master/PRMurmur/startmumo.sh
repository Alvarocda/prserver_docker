#!/bin/sh
cd mumo
echo "mumo is running"
python mumo.py
