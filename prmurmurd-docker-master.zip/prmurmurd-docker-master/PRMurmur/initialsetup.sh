#!/bin/sh
cd mumo/tools

python prbf2setup.py -s prmurmurpassword -i "../../PRMurmur.ice" 
