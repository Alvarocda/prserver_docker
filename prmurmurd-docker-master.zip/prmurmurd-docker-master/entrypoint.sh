#!/bin/sh
cd /home/prmurmur/PRMurmur
./prmurmurd.x64
cd /home/prmurmur/PRMurmur/mumo/tools
# lines from initialsetup.sh
python prbf2setup.py -s prmurmurpassword -i "../../PRMurmur.ice" 
# lines from createchannel.sh
IFS=""
python prbf2man.py -c $CHANNEL_ID -n $CHANNEL_NAME -f $IP:$PORT -b 1 -o "../modules-enabled/prbf2.ini" -s prmurmurpassword -i "../../PRMurmur.ice" 
# lines from startmumo.sh
cd /home/prmurmur/PRMurmur/mumo
echo "mumo is running"
python mumo.py
