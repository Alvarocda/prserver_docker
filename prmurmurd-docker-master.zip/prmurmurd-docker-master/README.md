# prmurmurd-docker

docker image build for prmurmurd.x64(PRMumble server)
All works here is belonging to its developper. Original PRMurmur is developped by R-DEV team.

## Overview
prmurmurd-docker is docker powered PRMurmur(mumble server for Project Reality). It doesn't require to be run on earlier ubuntu like 12.04, since all dependencies are included in this image. 

## Feature
* You can set up single mumble server.(It's not developed for multiple gameservers in single mumble, yet)
* You can configure IP and ports in environmental variables.
* You can receive a log if needed, mount the local drive to /home/prmurmur/PRMurmur.

## Usage
Simple enough.

```
$ sudo docker build . -t prmurmur-docker:latest
$ sudo docker run prmurmur-docker:latest -e CHANNEL_ID="shortchannelid" -e CHANNEL_NAME="Canned Catfood Gaming AAS/INS" -e IP="220.220.114.124" -e PORT="16567" -p 64740:64740 -p 64738:64738
```

For people who don't want to build it by yourself, I set up deployment token in my docker registry. You can use it on your own lisk since I cannot guallantee anything(mainly, SLA) about this registry.

```
$ sudo docker login -u prmurmur -p KKxPSzTpGeqra12QtdE8 dev.canned-catfood.com:5005
$ sudo docker pull dev.canned-catfood.com:5005/project-reality-japan/prmurmurd-docker:latest
$ sudo docker run prmurmur-docker:latest -e CHANNEL_ID="shortchannelid" -e CHANNEL_NAME="Canned Catfood Gaming AAS/INS" -e IP="220.220.114.124" -e PORT="16567" -p 64740:64740 -p 64738:64738
```

### Environmental variables
These configurations are used in initialization.
Usually, you set it on initialsetup.sh and createchannel.sh. Since it's docker, conversational setup is not suitable for this use so I wrapp them in entrypoint.sh and make it use ENVs.
#### IP
Gameserver ip addresss. like ```***.***.***.***``` .
#### PORT
Gameserver port number. like ```16567``` . Default number is set as 16567.
#### CHANNEL_NAME
Channel name that will be used on mumble channel name.
#### CHANNEL_ID
Channel short name that will be used on mumble to identify channel.